from init import *
from character import Character
class Adventurer(Character):
	def __init__(self, name, desc, age, stats, equipped, x, y):
		super().__init__([name, "me", "myself", "self"], desc, age, stats, equipped, "Are you going mad?")
		self.x, self.y = x, y

	@boxed
	def GetInventory(self):
		if self.equipped is not None:
			return "Inventory",f"Equipped: {self.equipped.name.title()}\n<n>\n{self.inventory.GetContentsAsText()}"
		else:
			return "Inventory",f"{self.inventory.GetContentsAsText()}"
