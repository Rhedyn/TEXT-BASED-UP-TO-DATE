from init import boxed
from thing import Thing
class Item(Thing):
	def __init__(self, aliases, desc, verbs, use, weight, value, urp=True, ip=True):
		super().__init__(aliases, desc, verbs, use, urp, ip)
		self.weight = weight
		self.value = value

	@boxed
	def AsText(self):
		return f"<c=cyan>{self.name}</c>", f"{self.desc}\n<h>\nIt weighs <c=magenta>{self.weight} kilogrammes</c>."
