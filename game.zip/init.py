import textwrap, os, re, sys
WIDTH, HEIGHT = input("\n  Please enter the window size you would like in the form cols*rows\n\n  I recommend 100*35\n\n > ").split('*')

WIDTH=int(WIDTH)
HEIGHT=int(HEIGHT)

os.system(f'mode con: cols={WIDTH} lines={HEIGHT}')
os.system('cls')

tw = textwrap.TextWrapper()
tw.width = WIDTH-6

color_codes = {
"<c=dred>":"\u001b[;31m",
"<c=red>":"\u001b[;31;1m",
"<c=dgreen>":"\u001b[;32m",
"<c=green>":"\u001b[;32;1m",
"<c=dyellow>":"\u001b[;33m",
"<c=yellow>":"\u001b[;33;1m",
"<c=dblue>":"\u001b[;34m",
"<c=blue>":"\u001b[;34;1m",
"<c=dmagenta>":"\u001b[;35m",
"<c=magenta>":"\u001b[;35;1m",
"<c=dcyan>":"\u001b[;36m",
"<c=cyan>":"\u001b[;36;1m",
"</c>":"\u001b[;0m"}

def boxed(func):
	def wrapper(*args, **kwargs):
		r = func(*args, **kwargs)

		if r == None:
			return None

		if isinstance(r, tuple):
			string = r[1]
			title = r[0]
			title = f"[{RemoveCommands(title, 0, 3)}]"
		else:
			string = r
			title = ''

		current_line = 1
		without_commands = ""
		for line in (string.split('\n')):
			if line != "<h>" and line != "<n>":
				line = RemoveCommands(line, current_line, 3)
			without_commands += line + '\n'
			current_line += 1

		return_string = f" ╔{title}{'═'*((WIDTH-4)-len(title))}╗\n ║{' '*(WIDTH-4)}║\n"

		for lines in (without_commands.split('\n')):
			for line in tw.wrap(lines):
				if line == "<h>":
					return_string += f" ║{' '*(WIDTH-4)}║ \n ╟{'─'*(WIDTH-4)}╢ \n ║{' '*(WIDTH-4)}║ \n"

				elif line == "<n>":
					return_string += f" ║{' '*(WIDTH-4)}║ \n"

				else:
					return_string += f" ║ {line}{' '*((WIDTH-6)-len(line))} ║ \n"

		return return_string + f" ║{' '*(WIDTH-4)}║ \n ╚{'═'*(WIDTH-4)}╝ \n"

	return wrapper


def RemoveCommands(text, line, padding):
	command = 0
	current_removed = 0

	while True:
		command = re.search('<.+?>', text)
		if command == None:
			break

		color_code = command.group()
		index = command.span()[0]
		text = text.replace(color_code, '', 1)
		current_removed += 1

	return text
