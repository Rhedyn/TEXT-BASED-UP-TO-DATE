from init import *
from map import Map
from item import Item
from container import Container
from adventurer import Adventurer
from character import Character
from commandhandler import CommandHandler

m = Map([
["Y", " ", "G", " ", "K"],
["W", "B", "T", "M", "E"],
[" ", " ", "H", " ", " "],
[" ", " ", "C", " ", " "]])
a = Adventurer("Player", "You", "18", [10, 10, 10, 10, 10, 10], {"head":None, "body":None, "arms":None, "legs":None, "feet":None, "main_hand":None, "off_hand":None}, 2, 3)

c = CommandHandler(a, m)

output = m.GetRoomAsText(a.x, a.y)

while True:
	os.system('cls')
	if output == None:
		output = m.GetRoomAsText(a.x, a.y)
	print("\n" + output)
	inp = input("> ").lower()

	tokens = inp.split(' ')
	if len(tokens) > 0:
		if tokens[0] == "look" or tokens[0] == 'l':
			if len(tokens) == 1:
				output = m.GetRoomAsText(a.x, a.y)
			else:
				output = c.Look(tokens[1:])


		elif tokens[0] == "go" or tokens[0] == 'g':
			output = c.Go(tokens[1:])

		elif tokens[0] == "take" or tokens[0] == 't':
			if len(tokens) >= 4:
				if "from" in tokens:
					tokens = ' '.join(tokens[1:]).split("from ")
					print([tokens[1], tokens[0][:len(tokens[0])-1]])
					output = c.TakeFrom([tokens[1], tokens[0][:len(tokens[0])-1]])
			else:
				output = c.Take(tokens[1:])

		elif tokens[0] == "drop" or tokens[0] == 'd':
			output = c.Drop(tokens[1:])

		elif tokens[0] == "inventory" or tokens[0] == "inv" or tokens[0] == 'i':
			output = a.GetInventory()

		elif tokens[0] == "equip" or tokens[0] == 'eq':
			output = c.Equip(tokens[1:])

		elif tokens[0] == "dequip" or tokens[0] == 'dq':
			output = c.Dequip()

		elif ' '.join(tokens) == "kill king":
			os.system('cls')
			output = c.KillKing()
			if output is not None:
				print("\n" + output)
				inp = input()
				while inp != "QUIT":
					inp = input()
				sys.exit()

		else:
			output = c.Use(tokens)


			#elif tokens[0] == '':
