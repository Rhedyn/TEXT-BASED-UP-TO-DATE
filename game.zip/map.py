from room import Room
from init import boxed
class Map():
	def __init__(self, map):
		self.Populate(map)

	def Populate(self, map):
		self.rooms = []
		for line in map:
			row = []
			for char in line:
				if char != ' ':
					row.append(Room(char))
				else:
					row.append(None)
			self.rooms.append(row)

	def GetExitsAsText(self, x, y):
		exits = ""
		if y > 0:
			if self.rooms[y-1][x] != None:
				exits += f"\n N: <c=green>{self.rooms[y-1][x].name}</c>"

		if y < len(self.rooms)-1:
			if self.rooms[y+1][x] != None:
				exits += f"\n S: <c=green>{self.rooms[y+1][x].name}</c>"

		if x < len(self.rooms[y])-1:
			if self.rooms[y][x+1] != None:
				exits += f"\n E: <c=green>{self.rooms[y][x+1].name}</c>"

		if x > 0:
			if self.rooms[y][x-1] != None:
				exits += f"\n W: <c=green>{self.rooms[y][x-1].name}</c>"

		return exits

	@boxed
	def GetRoomAsText(self, x, y):
		if self.rooms[y][x].HasContents():
			return f"<c=green>{self.rooms[y][x].name}</c>", f"{self.rooms[y][x].desc}\n<h>\nContents:\n<n>\n{self.rooms[y][x].inventory.GetContentsAsText()}\n<h>\nExits:\n<n>\n{self.GetExitsAsText(x, y)}"
		else:
			return f"<c=green>{self.rooms[y][x].name}</c>", f"{self.rooms[y][x].desc}\n<h>\n{self.GetExitsAsText(x, y)}"
