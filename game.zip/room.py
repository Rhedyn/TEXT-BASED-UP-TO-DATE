from container import Container
from item import *
from init import boxed
class Room():
	def __init__(self, char):
		self.inventory = Container()
		self.Determine(char)

	def Determine(self, char):
		if char == 'C':
			self.name = "Castle Courtyard"
			self.desc = "The <c=green>Courtyard</c> of a castle.\n<h>\nThe grounds are unkempt and overgrown, with a flagstone path barely visible through the matted weeds. Behind you, the portcullis is shut, and there are walls surrounding your entire perimiter. In front of you, there's a huge open door."

			#self.inventory.AddItems()

		elif char == 'H':
			self.name = "Entrance Hall"
			self.desc = "The <c=green>Entrance Hall</c> of a castle.\n<h>\nIt's delapidated, with the walls crumbling and letting in light shafts. There's barely anything left of the rug on the floor, and the wooden benches to the sides of the room are rotting and swollen with water."

			#self.inventory.AddItems()

		elif char == 'E':
			self.name = "East Wing"
			self.desc = "The <c=green>East Wing</c> of a castle.\n<h>\nThe outer wall is nearly gone, with a stiff breeze blowing in. The shrubbery outside is pouring in like leafy waves, and the floor is covered with sharp rubble."

			#self.inventory.AddItems()

		elif char == 'W':
			self.name = "West Wing"
			self.desc = "The <c=green>West Wing</c> of a castle.\n<h>\nIt's surprisingly intact, with most of the interior preserved, if old looking. The rug and upholstery are faded and sun-bleached, but would originally have been a vibrant. The dusty stained-glass windows give the room an ethereal feeling."

			#self.inventory.AddItems()

		elif char == 'B':
			self.name = "Barracks"
			self.desc = "The <c=green>Barracks</c> of a castle.\n<h>\nSave for a cracked window, the barracks feel nearly entirely preserved. The waxed plank floor feels solid under your feet, the weight of the history of the place is almost tangible. The dozen bunks on the eastern wall are still tidily made, with straw underneath fur. To the north, there's a door to a training yard, and to the east, racks of weapons and a few tables and chairs. There's a pack of cards spread out in poker hands left on one of the tables."

			self.inventory.AddItems(
			[Item(
			["short sword", "sword", "shortsword"],
			"A steel <c=cyan>shortsword</c> with a simple wooden handle and cast iron crossguard. It has a prism blade, and it feels strangely well balanced in your hand. Something about it is off...",
			["swing", "chop", "stab", "slice", "slash", "thrust"],
			"It feels like the air itself parts in it's path. It's almost scary how the edge rings with each particle of dust it splits.",
			4, 60),
			Item(
			["pack of cards", "cards", "pack", "card"],
			"A pack of <c=cyan>cards</c> laid out in 4 poker hands. Two of them are 5 high card, with one jack pair and, surprisingly, a royal flush.",
			["shuffle", "touch", "draw", "deal", "take"],
			"It feels wrong to disturb the cards. The closer you get to touching them, the more a sense of dread burns through your body. On second thoughts, you decide to leave them alone.",
			0.2, 4, False, False)]
			)

		elif char == 'T':
			self.name = "Throne Room"
			self.desc = "The <c=green>Throne Room</c> of a castle.\n<h>\nThe throne room lives up to it's title. At least, it would have done in the past. The throne, on a rasied section of the floor to the north, is split clean in half with each piece laying apart.\n<n>\nIn the center of the room is a round table, and to the sides of the room there's overgrown planting beds with a jungle of flowers and herbs twisting and sprawling out over the stone floor. The chairs around the table have dark stains beneath them. Behind the throne is a huge chest, about a meter tall, a meter deep and two meters wide."

			chest = Thing(["chest", "coffer"], "A huge <c=cyan>chest</c>. The lid is open.", [], "", False, False)

			chest.inventory.AddItem(
			Item(
			["king of spades", "card", "king"],
			"A playing <c=cyan>card</c>, the king of spades. It's warm and heavy in your hand, and you can feel a pulse.",
			["flip", "invert", "turn over"],
			"On the back of the card is a small mouth. It's grinning at you.",
			0.2, 4, True, True)
			)

			self.inventory.AddItems([
			Thing(["split throne", "throne"],
			"A stone <c=cyan>throne</c> cleaved clean in two. The two sides sit apart with not even a crack along the immaculate divide.",
			[], "", False, False),
			chest
			])

		elif char == 'K':
			self.name = "Kitchen"
			self.desc = "The <c=green>Kitchen</c> of a castle.\n<h>\nThe kitchen is, to put it simply, disgusting. Rotting food fills the shelving, unwashed dishes clutter the countertop by the sink. You swear you saw a rat scuttle out of view under a cupboard. It stinks of death, similar to six-month-old egg you remember finding in the back of the cupboard."

			self.inventory.AddItems([
			Thing(["rotten food", "rotting food", "food"],
			"Rotting <c=cyan>food</c>. It's pretty gross...",
			["touch", "touch the", "poke"], "Ugh...", False, False),
			Thing(["unwashed dishes", "dirty dishes", "dishes", "washing up"],
			"Unwashed <c=cyan>dishes</c>. There's life unknown to science living on them.",
			["touch", "touch the", "poke"], "Why...", False, False)
			])

		elif char == 'M':
			self.name = "Mess Hall"
			self.desc = "The <c=green>Mess Hall</c> of a castle.\n<h>\nThe hall is entirely empty, with a strange atmosphere of loss. You feel cold and wary even just standing there. This was a place often filled with noise and cheer, now with nothing but some broken furniture scattered in pieces about the place."

			#self.inventory.AddItems()

		elif char == 'G':
			self.name = "Garden"
			self.desc = "What was the <c=green>Garden</c> of a castle. It's barren."

			#self.inventory.AddItems()

		elif char == 'Y':
			self.name = "Training Yard"
			self.desc = "The <c=green>Training Yard</c> of a castle.\n<h>\nThe yard has patches of straw still visible through the vegetation on the floor. Collapsed archery targets were once stood up against the wall to the north. Rusted tools and weapons are scattered on the floor, so far decayed you can barely make out what they orignially were."

			self.inventory.AddItems([
			Thing(["rusted tools", "rusted weapons", "tools", "weapons"],
			"<c=cyan>Rusted tools</c>. Just looking at them makes you crave a tetanus shot.",
			["touch", "touch the", "poke"], "You're going to need that shot.", False, False)
			])

		else:
			self.name = "ERROR"
			self.desc = "ROOM CHAR NOT ACCOUNTED FOR"

	def HasContents(self):
		if len(self.inventory.contents) > 0:
			return True
		return False
