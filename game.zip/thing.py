from init import boxed
from container import Container
class Thing(object):
	def __init__(self, aliases, desc, verbs, use, urp, ip):
		self.name = aliases[0]
		self.aliases = aliases
		self.desc = desc
		self.verbs = verbs
		self.use = use
		self.usage_requires_posession = urp
		self.is_possessable = ip
		self.is_possessed = False

		self.inventory = Container()

	def Use(self, verb):
		if self.usage_requires_posession:
			if verb in self.verbs:
				if self.is_possessed:
					return f"<c=yellow>{verb.title()}</c> <c=cyan>{self.name}</c>", f"You <c=yellow>{verb}</c> the <c=cyan>{self.name}</c>.\n<h>\n{self.use}"
				else:
					return f"You can't <c=yellow>{verb}</c> the <c=cyan>{self.name}</c>, you must posess it first."

		else:
			if verb == "take":
				return f"You can't <c=yellow>{verb}</c> the <c=cyan>{self.name}</c>.\n<h>\n{self.use}"
			elif verb in self.verbs:
				return f"<c=yellow>{verb.title()}</c> <c=cyan>{self.name}</c>", f"You <c=yellow>{verb}</c> the <c=cyan>{self.name}</c>.\n<h>\n{self.use}"

		return f"You can't <c=yellow>{verb}</c> the <c=cyan>{self.name}</c>."

	@boxed
	def GetInventory(self):
		return f"Inventory:\n<n>\n {self.inventory.GetContentsAsText()}"

	def GetPrefix(self):
		return "the "
