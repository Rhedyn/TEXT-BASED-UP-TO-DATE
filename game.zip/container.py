class Container():
	def __init__(self, weight_limit = None):
		self.weight_limit = weight_limit
		self.total_weight = 0
		self.contents = {}

	def AddItems(self, items):
		returns = []
		for item in items:
			if (r := self.AddItem(item)) != None:
				returns.append(r)
		return returns

	def AddItem(self, item):
		if self.weight_limit != None:
			if not self.isAboveTotalWeight(item.weight):
				if item in self.contents:
					self.contents[item] += 1
				else:
					self.contents[item] = 1
					self.total_weight += item.weight
				return None
			return item
		else:
			if item in self.contents:
				self.contents[item] += 1
			else:
				self.contents[item] = 1
		return None

	def RemoveItem(self, name, quantity=1):
		weight = 0
		i = None
		for item in self.contents:
			if item.name == name:
				if self.contents[item] > quantity:
					if self.weight_limit != None:
						weight = item.weight
					i = item
					self.contents[item] -= quantity
				else:
					if self.weight_limit != None:
						weight = item.weight
					i = item
					self.contents = self.RemoveKey(item)
					break
		if self.weight_limit != None:
			self.total_weight -= item.weight
		if item == None:
			return None, 0
		return i, quantity

	def isAboveTotalWeight(self, additional_weight = 0):
		if self.weight_limit is not None:
			return self.total_weight + additional_weight > self.weight_limit
		else:
			return False

	def RemoveKey(self, key):
		r = self.contents
		del r[key]
		return r

	def GetContentsAsText(self):
		r = ''
		for item in self.contents:
			if item != None:
				if (quantity := self.contents[item]) > 1:
					r+= f"- {item.name.title()} ({quantity})\n"
				else:
					r+= f"- {item.name.title()}\n"
		return r
