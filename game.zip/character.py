from container import Container
from thing import Thing
class Character(Thing):
	def __init__(self, aliases, desc, age, stats, equipped, phrase):

		super().__init__(aliases, desc, ["talk to", "chat with", "speak to"], phrase, False, False)

		self.age = age
		self.strength = stats[0]
		self.dexterity = stats[1]
		self.constitution = stats[2]
		self.intelligence = stats[3]
		self.wisdom = stats[4]
		self.charisma = stats[5]

		self.equipped = None
