from init import *
class CommandHandler():
	def __init__(self, a, m):
		self.a = a
		self.m = m

	@boxed
	def Look(self, tokens):
		if len(tokens) >= 1:
			for alias in self.a.aliases:
				if ' '.join(tokens) == alias:
					return f"Looking at {tokens[0].title()}", "Lookin' good!"

			for thing in self.a.inventory.contents:
				if ' '.join(tokens) in item.aliases:
					print(item.is_possessed)
					if len(item.inventory.contents) >= 1:
						return f"Look {item.name.title()}", f"You look at {item.GetPrefix()}{item.name.title()}.\n<h>\n{item.desc}\n<h>\nContains:\n<n>\n{item.inventory.GetContentsAsText()}"
					else:
						return f"Look {item.name.title()}", f"You look at {item.GetPrefix()}{item.name.title()}.\n<h>\n{item.desc}"

			for thing in self.m.rooms[self.a.y][self.a.x].inventory.contents:
				if ' '.join(tokens) in thing.aliases:
					print(thing.is_possessable)
					print(thing.usage_requires_posession)
					if len(thing.inventory.contents) >= 1:
						return f"Look {thing.name.title()}", f"You look at {thing.GetPrefix()}{thing.name.title()}.\n<h>\n{thing.desc}\n<h>\nContains:\n<n>\n{thing.inventory.GetContentsAsText()}"
					else:
						return f"Look {thing.name.title()}", f"You look at {thing.GetPrefix()}{thing.name.title()}.\n<h>\n{thing.desc}"

			return "I can't see that."

	@boxed
	def Go(self, tokens):
		if len(tokens) >= 1:

			if tokens[0] == "north" or tokens[0] == 'n':
				tokens[0] = "North"
				if self.a.y > 0:
					if self.m.rooms[self.a.y-1][self.a.x] != None:
						self.a.y-=1
						return None

			elif tokens[0] == "south" or tokens[0] == 's':
				tokens[0] = "South"
				if self.a.y < len(self.m.rooms)-1:
					if self.m.rooms[self.a.y+1][self.a.x] != None:
						self.a.y+=1
						return None

			elif tokens[0] == "east" or tokens[0] == 'e':
				tokens[0] = "East"
				if self.a.x < len(self.m.rooms[self.a.y])-1:
					if self.m.rooms[self.a.y][self.a.x+1] != None:
						self.a.x +=1
						return None

			elif tokens[0] == "west" or tokens[0] == 'w':
				tokens[0] = "West"
				if self.a.x > 0:
					if self.m.rooms[self.a.y][self.a.x-1] != None:
						self.a.x -=1
						return None

			return f"Go {tokens[0]}", "I can't go that way!"

	@boxed
	def Take(self, tokens):
		if len(tokens) >= 1:
			for thing in self.m.rooms[self.a.y][self.a.x].inventory.contents:
				if ' '.join(tokens) in thing.aliases:
					if thing.is_possessable:
						t = self.m.rooms[self.a.y][self.a.x].inventory.RemoveItem(thing.name)
						if t[0] != None:
							t[0].is_possessed = True
							self.a.inventory.AddItem(t[0])
							return f"Took {t[0].name.title()}", f"You took the {t[0].name.title()}."
					else:
						return thing.Use("take")

		return "You can't take that."

	@boxed
	def TakeFrom(self, tokens):
		for thing in self.m.rooms[self.a.y][self.a.x].inventory.contents:
			if tokens[0] in thing.aliases:
				for item in thing.inventory.contents:
					if tokens[1] in item.aliases:
						i = thing.inventory.RemoveItem(item.name)
						if i[0] != None:
							i[0].is_possessed = True
							self.a.inventory.AddItem(i[0])
							return f"Took {i[0].name.title()} from {thing.name.title()}", f"You took the {i[0].name.title()}."
						else:
							return f"{tokens[0].title()} doesn't have {tokens[1]}."
					else:
						return thing.Use("try to take")

		return f"You can't take {tokens[1]} from {tokens[0]}."

	@boxed
	def Drop(self, tokens):
		if len(tokens) >= 1:
			for item in self.a.inventory.contents:
				if tokens[0] in item.aliases:
					i = self.a.inventory.RemoveItem(item.name)
					if i[0] != None:
						i[0].is_possessed = False
						self.m.rooms[self.a.y][self.a.x].inventory.AddItem(i[0])
						return f"Drop {i[0].name.title()}", f"You dropped the {i[0].name.title()}."
		return "You can't drop that."

	@boxed
	def Equip(self, tokens):
		for item in self.a.inventory.contents:
			if ' '.join(tokens) in item.aliases:
				i = self.a.inventory.RemoveItem(item.name)
				if self.a.equipped is None:
					self.a.equipped = i[0]
				else:
					self.a.inventory.AddItem(self.a.equipped)
					self.a.equipped = i[0]
				return f"Equipped {i[0].name.title()}."
		return f"Cannot equip {i[0].name.title()}."

	@boxed
	def Dequip(self):
		item = self.a.equipped
		if item is not None:
			self.a.inventory.AddItem(item)
			self.a.equipped = None
			return f"Dequipped {item.name.title()}."
		else:
			return "No item to dequip."

	@boxed
	def Use(self, tokens):
		for alias in self.a.aliases:
			if tokens[len(tokens)-1] == alias:
				if len(tokens) > 2:
					return self.a.Use(' '.join(tokens[:len(tokens)-1]))
				else:
					return self.a.Use(tokens[0])

		for thing in self.m.rooms[self.a.y][self.a.x].inventory.contents:
			for alias in thing.aliases:
				if tokens[len(tokens)-1] == alias:
					if len(tokens) > 2:
						return thing.Use(' '.join(tokens[:len(tokens)-1]))
					else:
						return thing.Use(tokens[0])

		for thing in self.a.inventory.contents:
			for alias in thing.aliases:
				if tokens[len(tokens)-1] == alias:
					if len(tokens) > 2:
						return thing.Use(' '.join(tokens[:len(tokens)-1]))
					else:
						return thing.Use(tokens[0])

	@boxed
	def KillKing(self):
		for item in self.a.inventory.contents:
			if "king" in item.aliases:
				if "sword" in self.a.equipped.aliases:
					return "Killing the king", "You take the sword, drop the king of spades to the floor, and force the blade directly through the centre.\n<n>\nYou hear a shrill scream as dust and smoke start to pour out around the sword, blinding you. As the air clears, you realise the castle has disappeared. You are free!\n<n>\nType QUIT to quit."
		return None
